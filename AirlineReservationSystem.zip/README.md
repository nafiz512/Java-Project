To run this project follow this steps<br>
1.install java ,netbins in your machine<br>
2.install Xamp for database <br>
3.create database name "atbs".<br>
4.import atb.sql file in your database<br>
5.end